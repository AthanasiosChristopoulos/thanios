import sys
from collections import defaultdict
import csv
import os
from collections import Counter
from data_in.constants import phy_map

collected_data_file = ""
phy_type_connection = ""

def classify_phy_type(phy_type_connection):

    phy_map_quality = {
        "802.11b (HR/DSSS)": "Very Bad", 
        "802.11a (OFDM)": "Bad", 
        "802.11g (ERP)": "Bad",   
        "802.11n (HT)": "Okay", 
        "802.11ac (VHT)": "Good",  
        "802.11ax (HEW)": "Great",  
    }

    return phy_map_quality.get(phy_type_connection, "Unknown")

# ======================================================================================================
# ======================================================================================================

def classify_rssi(rssi):

    if rssi > -30:
        return ("Very Good")
    elif rssi > -60:
        return ("Good")
    elif rssi > -70:
        return ("Okay")
    elif rssi > -80:
        return ("Weak")
    elif rssi > -90:
        return ("Very Weak")
    else:
        return ("Unusable")

# ======================================================================================================
# ======================================================================================================

def classify_throughput(throughput_mbps):

    if throughput_mbps > 130:
        return "Excellent Connection"
    elif throughput_mbps > 80:
        return "Good Connection"
    elif throughput_mbps > 40:
        return "Moderate Connection"
    elif throughput_mbps > 10:
        return "Slow Connection"
    else:
        return "Very Poor Connection"
    
# ======================================================================================================
# ======================================================================================================

def classify_network_density(network_density):

    if network_density > 130:
        return "Very Congested"
    elif network_density > 80:
        return "Congested"
    elif network_density > 40:
        return "Acceptable"
    elif network_density > 10:
        return "Low Density"
    else:
        return "Very Good Density"

# ======================================================================================================
# ======================================================================================================

def analyze_phy_type(collected_data_file):
    
    phy_types = []
    downgrade_count = 0
    
    with open(collected_data_file, mode='r', newline='', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        
        prev_phy_rank = None
        
        for row in reader:
            
            phy_type = row["PHY Type"].strip()

            phy_types.append(phy_type)
            
            phy_rank = {v: k for k, v in phy_map.items()}.get(phy_type)
            
            if prev_phy_rank is not None and phy_rank is not None and phy_rank < prev_phy_rank:
                downgrade_count += 1
            
            prev_phy_rank = phy_rank
    
    phy_type_connection = Counter(phy_types).most_common(1)[0][0]
    
    connection_status = classify_phy_type(phy_type_connection)

    print(f"Most frequently used PHY Type / PHY type used in the Connection : {phy_type_connection}")
    
    print(f"Connection status: {connection_status}")
    
    if (connection_status == "Bad" or connection_status == "Very Bad"):
        print("Your Access Point or your Wifi Card hardware is outdated")
        
    print(f"Number of downgrades: {downgrade_count}")

# ======================================================================================================
# ======================================================================================================

def analyze_signal_strength(collected_data_file):
        
    with open(collected_data_file, mode='r', newline='', encoding='utf-8') as file:
        reader = csv.DictReader(file)
                
        for row in reader:

            avg_signal_strength = row["Average Signal Strength"].strip()
            throughput = row["Throughput"].strip()
            
    
    rssi_status = classify_rssi(float(avg_signal_strength))
    throughput_status = classify_throughput(float(throughput))

    print(f"Signal Strength status: {rssi_status}")
    print(f"Signal Thougput status: {throughput_status}")

# ======================================================================================================
# ======================================================================================================

def analyse_network_density(network_density_file):
        
    with open(network_density_file, mode='r', newline='', encoding='utf-8') as file:

        reader = csv.DictReader(file)
        # print("CSV Headers:", reader.fieldnames)  # Debug: Print headers        
        for row in reader:
            
            network_density = row["Final Network Density"].strip()
            
    
    network_density_status = classify_network_density(float(network_density))

    print(f"Network Density status: {network_density_status}")


# ======================================================================================================
# ======================================================================================================\

if __name__ == "__main__":
    
    collected_data_file = sys.argv[1]
    print(collected_data_file)
    reduced_data_file = sys.argv[2]
    print(reduced_data_file)
    network_density_file = sys.argv[3]
    print(network_density_file) 


    analyze_phy_type(collected_data_file)
    analyze_signal_strength(reduced_data_file)
    analyse_network_density(network_density_file)


