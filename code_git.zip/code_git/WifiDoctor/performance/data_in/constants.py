# PHY Type Ranking
phy_map = {
    4: "802.11b (HR/DSSS)",
    5: "802.11a (OFDM)",
    6: "802.11g (ERP)",  
    7: "802.11n (HT)",
}
