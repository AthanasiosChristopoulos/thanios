#!/bin/bash

clear

PCAP_FILE_beacon="data_in/my_capture_beacon.pcap"

BEACON_FILE="data_out/beacon_file.txt"
DATA_FILE="data_out/data_file.txt"

COLLECTED_DATA="data_out/collected_data.csv"
REDUCED_DATA="data_out/reduced_data.csv"
NETWORK_DATA="data_out/network_density.csv"

MY_PACKET=1
if [ $MY_PACKET -eq 0 ]; then
    PCAP_FILE="data_in/HowIWiFi_PCAP.pcap"
else
    PCAP_FILE="data_in/my_capture_beacon.pcap"
fi

echo ""
echo "Extracting BSSID data from PCAP..."
echo ""

python3 parser.py "$PCAP_FILE_beacon" "$PCAP_FILE" "$BEACON_FILE" "$DATA_FILE" $MY_PACKET

echo ""
echo "Calculating data..."
echo ""
python3 monitor.py "$BEACON_FILE" "$DATA_FILE" $MY_PACKET

echo ""
echo "Performing Analysis..."
echo ""

python3 analyser.py "$COLLECTED_DATA" "$REDUCED_DATA" "$NETWORK_DATA"

echo ""
echo "Visualizing Results..."
echo ""

python3 visualizer.py