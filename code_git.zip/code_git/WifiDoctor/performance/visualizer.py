import csv
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os

# Define paths
DATA_OUT_DIR = "data_out"
REDUCED_DATA_FILE = os.path.join(DATA_OUT_DIR, "reduced_data.csv")
COLLECTED_DATA_FILE = os.path.join(DATA_OUT_DIR, "collected_data.csv")

# Ensure the output directory exists
os.makedirs(DATA_OUT_DIR, exist_ok=True)

# ======================================================================================================

def visualize_data():
    df = pd.read_csv(REDUCED_DATA_FILE)
    print("\n========= Wi-Fi Reduced Data =========")
    print(df.to_string(index=False))
    print("=====================================")

# ======================================================================================================

def channel_to_frequency_range(channel):
    if 1 <= channel <= 14:  
        center_freq = 2412 + (channel - 1) * 5  
        low = center_freq - 10          # 20MHz Bandwidth
        high = center_freq + 10
    elif 36 <= channel <= 64 or 100 <= channel <= 165:  
        center_freq = 5000 + channel * 5  
        low = center_freq - 20          # 40MHz Bandwidth
        high = center_freq + 20
    else:
        return None  

    return [low, center_freq - 5, center_freq, center_freq + 5, high]

# ======================================================================================================

def read_csv(file_path):
    bssid_data = {}

    with open(file_path, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            bssid = row['BSSID']
            channel = int(row['Channel'])
            signal_strength = float(row['Average Signal Strength']) + 100  

            frequency_range = channel_to_frequency_range(channel)
            if frequency_range:
                bssid_data[bssid] = (frequency_range, signal_strength)
    
    return bssid_data

# ======================================================================================================

def plot_bssid_channels(bssid_data):
    # Plot for 2.4 GHz range
    fig1, ax1 = plt.subplots(figsize=(8, 6))
    ax1.set_ylim([-10, 80])
    ax1.set_xlim([2377, 2500])
    ax1.set_xticks(np.arange(2377, 2500, 5))
    ax1.set_xlabel('Frequency (MHz)')
    ax1.set_ylabel('Signal Strength (+100 dBm)')
    ax1.grid(True)

    sorted_bssids_24ghz = sorted((bssid for bssid, (freq_range, strength) in bssid_data.items() if freq_range[0] < 2500), key=lambda x: bssid_data[x][1])

    for bssid in sorted_bssids_24ghz:
        freq_range, strength = bssid_data[bssid]
        x_values = [freq_range[0], freq_range[0], freq_range[-1], freq_range[-1]]
        y_values = [0, strength, strength, 0]
        ax1.fill_between(x_values, y_values, step="mid", alpha=0.7, label=bssid)

    ax1.legend(loc='best', fontsize=8)
    plt.suptitle('2.4 GHz BSSID Frequency Occupancy')
    plt.savefig(os.path.join(DATA_OUT_DIR, "2.4GHz_channel_overlap.png"))

    # Plot for 5 GHz range
    fig2, ax2 = plt.subplots(figsize=(8, 6))
    ax2.set_ylim([-10, 80])
    ax2.set_xlim([5100, 5900])
    ax2.set_xticks(np.arange(5100, 5900, 20))
    ax2.set_xlabel('Frequency (MHz)')
    ax2.set_ylabel('Signal Strength (+100 dBm)')
    ax2.grid(True)

    sorted_bssids_5ghz = sorted((bssid for bssid, (freq_range, strength) in bssid_data.items() if freq_range[0] >= 2500), key=lambda x: bssid_data[x][1])

    for bssid in sorted_bssids_5ghz:
        freq_range, strength = bssid_data[bssid]
        x_values = [freq_range[0], freq_range[0], freq_range[-1], freq_range[-1]]
        y_values = [0, strength, strength, 0]
        ax2.fill_between(x_values, y_values, step="mid", alpha=0.7, label=bssid)

    ax2.legend(loc='best', fontsize=8)
    plt.suptitle('5 GHz BSSID Frequency Occupancy')
    plt.savefig(os.path.join(DATA_OUT_DIR, "5GHz_channel_overlap.png"))

# ======================================================================================================

def signal_strength_time():
    df = pd.read_csv(COLLECTED_DATA_FILE)

    df['Time Arrived'] = df['Time Arrived'].astype(float)
    df = df.sort_values(by='Time Arrived')

    plt.figure(figsize=(10, 5))
    plt.plot(df['Time Arrived'], df['Signal Strength'], marker='o', linestyle='-', color='b', label='Signal Strength (dBm)')

    plt.xlabel('Time Arrived (s)')
    plt.ylabel('Signal Strength (dBm)')
    plt.title('Wi-Fi Signal Strength Over Time')
    plt.legend()
    plt.grid(True)

    plt.savefig(os.path.join(DATA_OUT_DIR, "signal_strength_plot.png"))
    print("Plot saved in 'data_out' directory.")

# ======================================================================================================

if __name__ == "__main__":
    visualize_data()
    bssid_data = read_csv(REDUCED_DATA_FILE)
    # plot_bssid_channels(bssid_data)
    # signal_strength_time()
