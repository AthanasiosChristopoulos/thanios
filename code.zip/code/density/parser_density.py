import pyshark
import sys

def parse_pcap(file_path, output_file, max_packets=50):

    cap = pyshark.FileCapture(file_path, display_filter="wlan")

    packet_count = 0
    bssids = set()  

    for pkt in cap:
        try:
            wlan_layer = pkt.wlan
            frame_type_subtype = getattr(wlan_layer, 'fc_type_subtype', 'N/A')

            if frame_type_subtype != "0x0008": 
                continue  
            print(wlan_layer)

            bssid = getattr(wlan_layer, 'bssid', 'N/A')
            if bssid != "N/A":
                bssids.add(bssid)

            packet_count += 1
            if packet_count >= max_packets:
                break  

        except AttributeError:
            continue

    cap.close()

    with open(output_file, 'w') as f:
        for bssid in bssids:
            f.write(bssid + "\n")


if __name__ == "__main__":
    
    print("Executing Parser")

    if len(sys.argv) < 3:
    
        print("Usage: python pcap_parser.py <pcap_file> <output_file>")
        sys.exit(1)

    pcap_file = sys.argv[1]
    output_file = sys.argv[2]
    parse_pcap(pcap_file, output_file)
