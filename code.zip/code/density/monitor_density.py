import sys

class PerformanceMonitor:
    def __init__(self, bssid_file):
        self.bssid_file = bssid_file

    def estimate_density(self):
        try:
            with open(self.bssid_file, 'r') as f:
                bssids = f.readlines()
                unique_bssids = set(b.strip() for b in bssids)

            return len(unique_bssids)

        except FileNotFoundError:
            print(f"Error: File {self.bssid_file} not found!")
            return 0

    def print_density_report(self):
        density = self.estimate_density()
        print("\n========= Wi-Fi Density Report =========")
        print(f"Unique SSIDs (BSSIDs): {density}")
        print("========================================")

if __name__ == "__main__":

    print("Executing monitor ...")
    
    if len(sys.argv) < 2:
        print("Usage: python performance_monitor.py <bssid_file>")
        sys.exit(1)

    monitor = PerformanceMonitor(sys.argv[1])
    monitor.print_density_report()
