#!/bin/bash

clear

INPUT_FILE="input_0.asm"  # No spaces around '=' and wrapped in quotes

gcc assembler.c -o assembler
# gcc assembler_sotiriadis.c -o assembler

./assembler "$INPUT_FILE" -o output.coe  # Use quotes and fix argument format

python3 hex_to_binary.py "$INPUT_FILE"   # Use quotes and the correct variable

cp output.coe /home/ds123f15/Documents/Organization/Xilinx_Projects/new_2/test_all.coe
