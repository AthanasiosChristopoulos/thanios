from tabulate import tabulate
import sys
print_file = sys.argv[1]

print(f"print_file: {print_file}")

def format_binary(hex_int):
    # Convert integer to hexadecimal string and then to binary (32-bit padded)
    binary_str = bin(hex_int)[2:].zfill(32)
    
    # Extract opcode (first 6 bits)
    opcode = binary_str[:6]
    
    if opcode == "100000":
        # Format: 100000  XXXXX  XXXXX  XXXXX  XXXXXXX
        formatted_bin = f"{binary_str[:6]}  {binary_str[6:11]}  {binary_str[11:16]}  {binary_str[16:21]}  {binary_str[21:]}"
    else:
        # Format: XXXXXXX  XXXXX  XXXXX  XXXXXXXXXXXXXXXX
        formatted_bin = f"{binary_str[:6]}  {binary_str[6:11]}  {binary_str[11:16]}  {binary_str[16:]}"
    
    return formatted_bin

def process_coe_file(file_path):
    # Read the .coe file and extract hex values from the memory_initialization_vector
    with open(file_path, 'r') as file:
        lines = file.readlines()
    
    # Skip the first 3 lines which are metadata
    hex_values = []
    for line in lines[2:]:
        # Remove any whitespace, commas, and semicolons, then skip empty lines
        cleaned_line = line.strip().replace(',', '').replace(';', '')
        if cleaned_line:
            try:
                hex_values.append(int(cleaned_line, 16))  # Convert hex string to integer
            except ValueError:
                print(f"Skipping invalid hex value: {line.strip()}")
  
    with open(print_file, 'r') as asm_file:
        asm_lines = asm_file.readlines()
    
    table_data = []
    for i, (hex_val, asm_line) in enumerate(zip(hex_values, asm_lines)):
        table_data.append([i, asm_line.strip(), hex(hex_val).upper(), format_binary(hex_val)])
    
    print(tabulate(table_data, headers=["Index", "Assembly Line", "Hex Value", "Formatted Binary"], tablefmt="grid"))

# Example usage:
coe_file_path = 'output.coe'  # Provide the path to your .coe file here
process_coe_file(coe_file_path)
