#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 100

int get_register(char *reg) {
    if (strcmp(reg, "$zero") == 0 || strcmp(reg, "r0") == 0 || strcmp(reg, "$0") == 0) return 0;
    if (strcmp(reg, "$at") == 0 || strcmp(reg, "r1") == 0 || strcmp(reg, "$1") == 0) return 1;
    if (strcmp(reg, "$v0") == 0 || strcmp(reg, "r2") == 0 || strcmp(reg, "$2") == 0) return 2;
    if (strcmp(reg, "$v1") == 0 || strcmp(reg, "r3") == 0 || strcmp(reg, "$3") == 0) return 3;
    if (strcmp(reg, "$a0") == 0 || strcmp(reg, "r4") == 0 || strcmp(reg, "$4") == 0) return 4;
    if (strcmp(reg, "$a1") == 0 || strcmp(reg, "r5") == 0 || strcmp(reg, "$5") == 0) return 5;
    if (strcmp(reg, "$a2") == 0 || strcmp(reg, "r6") == 0 || strcmp(reg, "$6") == 0) return 6;
    if (strcmp(reg, "$a3") == 0 || strcmp(reg, "r7") == 0 || strcmp(reg, "$7") == 0) return 7;
    if (strcmp(reg, "$t0") == 0 || strcmp(reg, "r8") == 0 || strcmp(reg, "$8") == 0) return 8;
    if (strcmp(reg, "$t1") == 0 || strcmp(reg, "r9") == 0 || strcmp(reg, "$9") == 0) return 9;
    if (strcmp(reg, "$t2") == 0 || strcmp(reg, "r10") == 0 || strcmp(reg, "$10") == 0) return 10;
    if (strcmp(reg, "$t3") == 0 || strcmp(reg, "r11") == 0 || strcmp(reg, "$11") == 0) return 11;
    if (strcmp(reg, "$t4") == 0 || strcmp(reg, "r12") == 0 || strcmp(reg, "$12") == 0) return 12;
    if (strcmp(reg, "$t5") == 0 || strcmp(reg, "r13") == 0 || strcmp(reg, "$13") == 0) return 13;
    if (strcmp(reg, "$t6") == 0 || strcmp(reg, "r14") == 0 || strcmp(reg, "$14") == 0) return 14;
    if (strcmp(reg, "$t7") == 0 || strcmp(reg, "r15") == 0 || strcmp(reg, "$15") == 0) return 15;
    if (strcmp(reg, "$s0") == 0 || strcmp(reg, "r16") == 0 || strcmp(reg, "$16") == 0) return 16;
    if (strcmp(reg, "$s1") == 0 || strcmp(reg, "r17") == 0 || strcmp(reg, "$17") == 0) return 17;
    if (strcmp(reg, "$s2") == 0 || strcmp(reg, "r18") == 0 || strcmp(reg, "$18") == 0) return 18;
    if (strcmp(reg, "$s3") == 0 || strcmp(reg, "r19") == 0 || strcmp(reg, "$19") == 0) return 19;
    if (strcmp(reg, "$s4") == 0 || strcmp(reg, "r20") == 0 || strcmp(reg, "$20") == 0) return 20;
    if (strcmp(reg, "$s5") == 0 || strcmp(reg, "r21") == 0 || strcmp(reg, "$21") == 0) return 21;
    if (strcmp(reg, "$s6") == 0 || strcmp(reg, "r22") == 0 || strcmp(reg, "$22") == 0) return 22;
    if (strcmp(reg, "$s7") == 0 || strcmp(reg, "r23") == 0 || strcmp(reg, "$23") == 0) return 23;
    if (strcmp(reg, "$t8") == 0 || strcmp(reg, "r24") == 0 || strcmp(reg, "$24") == 0) return 24;
    if (strcmp(reg, "$t9") == 0 || strcmp(reg, "r25") == 0 || strcmp(reg, "$25") == 0) return 25;
    if (strcmp(reg, "$k0") == 0 || strcmp(reg, "r26") == 0 || strcmp(reg, "$26") == 0) return 26;
    if (strcmp(reg, "$k1") == 0 || strcmp(reg, "r27") == 0 || strcmp(reg, "$27") == 0) return 27;
    if (strcmp(reg, "$gp") == 0 || strcmp(reg, "r28") == 0 || strcmp(reg, "$28") == 0) return 28;
    if (strcmp(reg, "$sp") == 0 || strcmp(reg, "r29") == 0 || strcmp(reg, "$29") == 0) return 29;
    if (strcmp(reg, "$fp") == 0 || strcmp(reg, "r30") == 0 || strcmp(reg, "$30") == 0) return 30;
    if (strcmp(reg, "$ra") == 0 || strcmp(reg, "r31") == 0 || strcmp(reg, "$31") == 0) return 31;
    return -1;
}



// Encode R-type instruction
unsigned int encode_r_type(char *opcode, char *rs, char *rd, char *rt) {
    int rs_num = get_register(rs);
    int rd_num = get_register(rd);
    int rt_num = get_register(rt);
    int funct = 0;

    if (strcmp(opcode, "add") == 0) funct = 0x30;
    else if (strcmp(opcode, "sub") == 0) funct = 0x31;
    else if (strcmp(opcode, "and") == 0) funct = 0x32;
    else if (strcmp(opcode, "not") == 0) funct = 0x34;
    else if (strcmp(opcode, "or") == 0) funct = 0x33;
    else if (strcmp(opcode, "sra") == 0) funct = 0x38;
    else if (strcmp(opcode, "sll") == 0) funct = 0x3A;
    else if (strcmp(opcode, "srl") == 0) funct = 0x39;
    else if (strcmp(opcode, "rol") == 0) {
        funct = 0x3C;
        rt_num = 0;
    }
    else if (strcmp(opcode, "ror") == 0) {
        funct = 0x3D;
        rt_num = 0;
    }
    else return 0;

    return (0x20 << 26) | (rs_num << 21) | (rd_num << 16) | (rt_num << 11) | (0 << 6) | funct;
}

// Encode I-type instruction
unsigned int encode_i_type(char *opcode, char *rd, char *rs, char *imm) {
    int rs_num = get_register(rs);
    int rd_num = get_register(rd);
    int imm_val = atoi(imm);
    int opcode_bin = 0;

    if (strcmp(opcode, "addi") == 0) opcode_bin = 0x30;
    else if (strcmp(opcode, "andi") == 0) opcode_bin = 0x32;
    else if (strcmp(opcode, "ori") == 0) opcode_bin = 0x33;
    else if (strcmp(opcode, "li") == 0){
        opcode_bin = 0x38; 
        rs_num = 0;         
    }
    else if (strcmp(opcode, "lui") == 0) opcode_bin = 0x39;
    else if (strcmp(opcode, "beq") == 0) opcode_bin = 0x10;
    else if (strcmp(opcode, "bne") == 0) opcode_bin = 0x11;
    else if (strcmp(opcode, "b") == 0) opcode_bin = 0x3F;
    else return 0;

    return (opcode_bin << 26) | (rs_num << 21) | (rd_num << 16) | (imm_val & 0xFFFF);
}

// Encode Load/Store instructions
unsigned int encode_load_store(char *opcode, char *rd, char *offset, char *rs) {
    int rs_num = get_register(rs);
    int rd_num = get_register(rd);
    int imm_val = atoi(offset);
    int opcode_bin = 0;

    if (strcmp(opcode, "lw") == 0) opcode_bin = 0x0F;
    else if (strcmp(opcode, "sw") == 0) opcode_bin = 0x1F;
    else if (strcmp(opcode, "lb") == 0) opcode_bin = 0x03;
    else if (strcmp(opcode, "sb") == 0) opcode_bin = 0x07;
    else return 0;

    return (opcode_bin << 26) | (rs_num << 21) | (rd_num << 16) | (imm_val & 0xFFFF);
}

int main(int argc, char *argv[]) {
    if (argc < 4 || strcmp(argv[2], "-o") != 0) {
        printf("Usage: %s <input.asm> -o <output.coe>\n", argv[0]);
        return 1;
    }

    FILE *input = fopen(argv[1], "r");
    FILE *output = fopen(argv[3], "w");

    if (!input || !output) {
        printf("Error opening file!\n");
        return 1;
    }

    fprintf(output, "memory_initialization_radix=16;\n");
    fprintf(output, "memory_initialization_vector=\n");

    char line[MAX_LINE_LENGTH];
    while (fgets(line, sizeof(line), input)) {
        char opcode[10], rd[10], rs[10], rt[10], imm[10];
        unsigned int machine_code = 0;
        unsigned int result = 0;

        if (sscanf(line, "%s %[^,], %[^,], %s", opcode, rd, rs, rt) == 4 && (strcmp(opcode, "add") == 0 || strcmp(opcode, "sub") == 0 || 
                strcmp(opcode, "and") == 0 || strcmp(opcode, "or") == 0 || 
                strcmp(opcode, "not") == 0 || strcmp(opcode, "sra") == 0 || 
                strcmp(opcode, "sll") == 0 || strcmp(opcode, "srl") == 0 || 
                strcmp(opcode, "rol") == 0 || strcmp(opcode, "ror") == 0)) {

                machine_code = encode_r_type(opcode, rd, rs, rt);
        } 

        else if (sscanf(line, "%s %[^,], %[^,], %s", opcode, rd, rs, imm) == 4) {
            machine_code = encode_i_type(opcode, rd, rs, imm);

        }

        else if (sscanf(line, "%s %[^,], %[^()](%[^)])", opcode, rd, imm, rs) == 4) {
            machine_code = encode_load_store(opcode, rd, imm, rs);
        }

        else if (sscanf(line, "%s %s", opcode, imm) == 2 && strcmp(opcode, "b") == 0) {
            machine_code = encode_i_type(opcode, "$zero", "$zero", imm);
        }

        else if (sscanf(line, "%s %[^,], %s", opcode, rd, rs) == 3 && (strcmp(opcode, "add") == 0 || strcmp(opcode, "sub") == 0 || 
                strcmp(opcode, "and") == 0 || strcmp(opcode, "or") == 0 || 
                strcmp(opcode, "not") == 0 || strcmp(opcode, "sra") == 0 || 
                strcmp(opcode, "sll") == 0 || strcmp(opcode, "srl") == 0 || 
                strcmp(opcode, "rol") == 0 || strcmp(opcode, "ror") == 0)) {

            machine_code = encode_r_type(opcode, rd, rs, "$zero");

        }

        else if (sscanf(line, "%s %[^,], %s", opcode, rd, imm) == 3) {
            machine_code = encode_i_type(opcode, rd, "$zero", imm);

        }


        fprintf(output, "%08X,\n", machine_code);
    }

    fseek(output, -2, SEEK_END);
    fprintf(output, ";\n");

    fclose(input);
    fclose(output);

    printf("Translation complete! Output written to %s\n", argv[3]);
    return 0;
}