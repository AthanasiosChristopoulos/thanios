/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ds123f15/Documents/Organization/Xilinx_Projects/new_2/ram_controller.vhd";
extern char *IEEE_P_2592010699;



static void work_a_0091327676_3212880686_p_0(char *t0)
{
    char t32[16];
    char t34[16];
    char t39[16];
    char t46[16];
    char t47[16];
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    int t19;
    int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t33;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    char *t40;
    int t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    unsigned int t48;
    static char *nl0[] = {&&LAB5, &&LAB5, &&LAB3, &&LAB4, &&LAB5, &&LAB5, &&LAB5, &&LAB5, &&LAB5};

LAB0:    xsi_set_current_line(35, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 3784);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(37, ng0);
    t4 = (t0 + 1352U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)2);
    if (t7 != 0)
        goto LAB6;

LAB8:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 3928);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(41, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t9 = (31 - 11);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t4 = (t0 + 3864);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 10U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(42, ng0);
    t1 = (t0 + 3992);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);

LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t6 = (t3 == (unsigned char)2);
    if (t6 != 0)
        goto LAB9;

LAB11:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 3992);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(49, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t9 = (31 - 11);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t4 = (t0 + 3864);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 10U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(50, ng0);
    t1 = (t0 + 3992);
    t2 = (t1 + 56U);
    t4 = *((char **)t2);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(52, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t9 = (31 - 1);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t4 = (t0 + 6514);
    t17 = xsi_mem_cmp(t4, t1, 2U);
    if (t17 == 1)
        goto LAB13;

LAB18:    t8 = (t0 + 6516);
    t18 = xsi_mem_cmp(t8, t1, 2U);
    if (t18 == 1)
        goto LAB14;

LAB19:    t13 = (t0 + 6518);
    t19 = xsi_mem_cmp(t13, t1, 2U);
    if (t19 == 1)
        goto LAB15;

LAB20:    t15 = (t0 + 6520);
    t20 = xsi_mem_cmp(t15, t1, 2U);
    if (t20 == 1)
        goto LAB16;

LAB21:
LAB17:    xsi_set_current_line(70, ng0);
    t1 = xsi_get_transient_memory(32U);
    memset(t1, 0, 32U);
    t2 = t1;
    memset(t2, (unsigned char)2, 32U);
    t4 = (t0 + 3928);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 32U);
    xsi_driver_first_trans_fast_port(t4);

LAB12:
LAB10:    goto LAB2;

LAB5:    xsi_set_current_line(74, ng0);
    t1 = xsi_get_transient_memory(10U);
    memset(t1, 0, 10U);
    t2 = t1;
    memset(t2, (unsigned char)2, 10U);
    t4 = (t0 + 3864);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 10U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(75, ng0);
    t1 = xsi_get_transient_memory(32U);
    memset(t1, 0, 32U);
    t2 = t1;
    memset(t2, (unsigned char)2, 32U);
    t4 = (t0 + 3928);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t1, 32U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB2;

LAB6:    xsi_set_current_line(38, ng0);
    t4 = (t0 + 1032U);
    t8 = *((char **)t4);
    t9 = (31 - 11);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t4 = (t8 + t11);
    t12 = (t0 + 3864);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t4, 10U);
    xsi_driver_first_trans_fast_port(t12);
    goto LAB7;

LAB9:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 1032U);
    t4 = *((char **)t1);
    t9 = (31 - 11);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t4 + t11);
    t5 = (t0 + 3864);
    t8 = (t5 + 56U);
    t12 = *((char **)t8);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t1, 10U);
    xsi_driver_first_trans_fast_port(t5);
    goto LAB10;

LAB13:    xsi_set_current_line(54, ng0);
    t21 = (t0 + 1192U);
    t22 = *((char **)t21);
    t23 = (31 - 7);
    t24 = (t23 * 1U);
    t25 = (0 + t24);
    t21 = (t22 + t25);
    t26 = (t0 + 1672U);
    t27 = *((char **)t26);
    t28 = (31 - 23);
    t29 = (t28 * 1U);
    t30 = (0 + t29);
    t26 = (t27 + t30);
    t33 = ((IEEE_P_2592010699) + 4000);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 7;
    t36 = (t35 + 4U);
    *((int *)t36) = 0;
    t36 = (t35 + 8U);
    *((int *)t36) = -1;
    t37 = (0 - 7);
    t38 = (t37 * -1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t36 = (t39 + 0U);
    t40 = (t36 + 0U);
    *((int *)t40) = 23;
    t40 = (t36 + 4U);
    *((int *)t40) = 0;
    t40 = (t36 + 8U);
    *((int *)t40) = -1;
    t41 = (0 - 23);
    t38 = (t41 * -1);
    t38 = (t38 + 1);
    t40 = (t36 + 12U);
    *((unsigned int *)t40) = t38;
    t31 = xsi_base_array_concat(t31, t32, t33, (char)97, t21, t34, (char)97, t26, t39, (char)101);
    t38 = (8U + 24U);
    t3 = (32U != t38);
    if (t3 == 1)
        goto LAB23;

LAB24:    t40 = (t0 + 3928);
    t42 = (t40 + 56U);
    t43 = *((char **)t42);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    memcpy(t45, t31, 32U);
    xsi_driver_first_trans_fast_port(t40);
    goto LAB12;

LAB14:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t9 = (31 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t4 = (t0 + 1192U);
    t5 = *((char **)t4);
    t23 = (31 - 7);
    t24 = (t23 * 1U);
    t25 = (0 + t24);
    t4 = (t5 + t25);
    t12 = ((IEEE_P_2592010699) + 4000);
    t13 = (t34 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 31;
    t14 = (t13 + 4U);
    *((int *)t14) = 24;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t17 = (24 - 31);
    t28 = (t17 * -1);
    t28 = (t28 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t28;
    t14 = (t39 + 0U);
    t15 = (t14 + 0U);
    *((int *)t15) = 7;
    t15 = (t14 + 4U);
    *((int *)t15) = 0;
    t15 = (t14 + 8U);
    *((int *)t15) = -1;
    t18 = (0 - 7);
    t28 = (t18 * -1);
    t28 = (t28 + 1);
    t15 = (t14 + 12U);
    *((unsigned int *)t15) = t28;
    t8 = xsi_base_array_concat(t8, t32, t12, (char)97, t1, t34, (char)97, t4, t39, (char)101);
    t15 = (t0 + 1672U);
    t16 = *((char **)t15);
    t28 = (31 - 15);
    t29 = (t28 * 1U);
    t30 = (0 + t29);
    t15 = (t16 + t30);
    t22 = ((IEEE_P_2592010699) + 4000);
    t26 = (t47 + 0U);
    t27 = (t26 + 0U);
    *((int *)t27) = 15;
    t27 = (t26 + 4U);
    *((int *)t27) = 0;
    t27 = (t26 + 8U);
    *((int *)t27) = -1;
    t19 = (0 - 15);
    t38 = (t19 * -1);
    t38 = (t38 + 1);
    t27 = (t26 + 12U);
    *((unsigned int *)t27) = t38;
    t21 = xsi_base_array_concat(t21, t46, t22, (char)97, t8, t32, (char)97, t15, t47, (char)101);
    t38 = (8U + 8U);
    t48 = (t38 + 16U);
    t3 = (32U != t48);
    if (t3 == 1)
        goto LAB25;

LAB26:    t27 = (t0 + 3928);
    t31 = (t27 + 56U);
    t33 = *((char **)t31);
    t35 = (t33 + 56U);
    t36 = *((char **)t35);
    memcpy(t36, t21, 32U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB12;

LAB15:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t9 = (31 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t4 = (t0 + 1192U);
    t5 = *((char **)t4);
    t23 = (31 - 7);
    t24 = (t23 * 1U);
    t25 = (0 + t24);
    t4 = (t5 + t25);
    t12 = ((IEEE_P_2592010699) + 4000);
    t13 = (t34 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 31;
    t14 = (t13 + 4U);
    *((int *)t14) = 16;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t17 = (16 - 31);
    t28 = (t17 * -1);
    t28 = (t28 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t28;
    t14 = (t39 + 0U);
    t15 = (t14 + 0U);
    *((int *)t15) = 7;
    t15 = (t14 + 4U);
    *((int *)t15) = 0;
    t15 = (t14 + 8U);
    *((int *)t15) = -1;
    t18 = (0 - 7);
    t28 = (t18 * -1);
    t28 = (t28 + 1);
    t15 = (t14 + 12U);
    *((unsigned int *)t15) = t28;
    t8 = xsi_base_array_concat(t8, t32, t12, (char)97, t1, t34, (char)97, t4, t39, (char)101);
    t15 = (t0 + 1672U);
    t16 = *((char **)t15);
    t28 = (31 - 7);
    t29 = (t28 * 1U);
    t30 = (0 + t29);
    t15 = (t16 + t30);
    t22 = ((IEEE_P_2592010699) + 4000);
    t26 = (t47 + 0U);
    t27 = (t26 + 0U);
    *((int *)t27) = 7;
    t27 = (t26 + 4U);
    *((int *)t27) = 0;
    t27 = (t26 + 8U);
    *((int *)t27) = -1;
    t19 = (0 - 7);
    t38 = (t19 * -1);
    t38 = (t38 + 1);
    t27 = (t26 + 12U);
    *((unsigned int *)t27) = t38;
    t21 = xsi_base_array_concat(t21, t46, t22, (char)97, t8, t32, (char)97, t15, t47, (char)101);
    t38 = (16U + 8U);
    t48 = (t38 + 8U);
    t3 = (32U != t48);
    if (t3 == 1)
        goto LAB27;

LAB28:    t27 = (t0 + 3928);
    t31 = (t27 + 56U);
    t33 = *((char **)t31);
    t35 = (t33 + 56U);
    t36 = *((char **)t35);
    memcpy(t36, t21, 32U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB12;

LAB16:    xsi_set_current_line(68, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t9 = (31 - 31);
    t10 = (t9 * 1U);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t4 = (t0 + 1192U);
    t5 = *((char **)t4);
    t23 = (31 - 7);
    t24 = (t23 * 1U);
    t25 = (0 + t24);
    t4 = (t5 + t25);
    t12 = ((IEEE_P_2592010699) + 4000);
    t13 = (t34 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 31;
    t14 = (t13 + 4U);
    *((int *)t14) = 8;
    t14 = (t13 + 8U);
    *((int *)t14) = -1;
    t17 = (8 - 31);
    t28 = (t17 * -1);
    t28 = (t28 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t28;
    t14 = (t39 + 0U);
    t15 = (t14 + 0U);
    *((int *)t15) = 7;
    t15 = (t14 + 4U);
    *((int *)t15) = 0;
    t15 = (t14 + 8U);
    *((int *)t15) = -1;
    t18 = (0 - 7);
    t28 = (t18 * -1);
    t28 = (t28 + 1);
    t15 = (t14 + 12U);
    *((unsigned int *)t15) = t28;
    t8 = xsi_base_array_concat(t8, t32, t12, (char)97, t1, t34, (char)97, t4, t39, (char)101);
    t28 = (24U + 8U);
    t3 = (32U != t28);
    if (t3 == 1)
        goto LAB29;

LAB30:    t15 = (t0 + 3928);
    t16 = (t15 + 56U);
    t21 = *((char **)t16);
    t22 = (t21 + 56U);
    t26 = *((char **)t22);
    memcpy(t26, t8, 32U);
    xsi_driver_first_trans_fast_port(t15);
    goto LAB12;

LAB22:;
LAB23:    xsi_size_not_matching(32U, t38, 0);
    goto LAB24;

LAB25:    xsi_size_not_matching(32U, t48, 0);
    goto LAB26;

LAB27:    xsi_size_not_matching(32U, t48, 0);
    goto LAB28;

LAB29:    xsi_size_not_matching(32U, t28, 0);
    goto LAB30;

}


extern void work_a_0091327676_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0091327676_3212880686_p_0};
	xsi_register_didat("work_a_0091327676_3212880686", "isim/tb_IF_DEC_ALU_isim_beh.exe.sim/work/a_0091327676_3212880686.didat");
	xsi_register_executes(pe);
}
