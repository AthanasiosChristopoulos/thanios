/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ds123f15/Documents/Organization/Xilinx_Projects/new_2/Extender.vhd";
extern char *IEEE_P_2592010699;



static void work_a_3056889143_3212880686_p_0(char *t0)
{
    char t12[16];
    char t14[16];
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t13;
    char *t15;
    char *t16;
    int t17;
    unsigned int t18;
    unsigned char t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    int t30;
    unsigned int t31;
    unsigned int t32;
    int t33;
    unsigned int t34;

LAB0:    xsi_set_current_line(21, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 5370);
    t4 = 1;
    if (2U == 2U)
        goto LAB5;

LAB6:    t4 = 0;

LAB7:    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 5388);
    t4 = 1;
    if (2U == 2U)
        goto LAB15;

LAB16:    t4 = 0;

LAB17:    if (t4 != 0)
        goto LAB13;

LAB14:    xsi_set_current_line(26, ng0);
    t1 = xsi_get_transient_memory(16U);
    memset(t1, 0, 16U);
    t2 = t1;
    t3 = (t0 + 1032U);
    t6 = *((char **)t3);
    t17 = (15 - 15);
    t5 = (t17 * -1);
    t18 = (1U * t5);
    t25 = (0 + t18);
    t3 = (t6 + t25);
    t4 = *((unsigned char *)t3);
    if (-1 == 1)
        goto LAB23;

LAB24:    t26 = 0;

LAB25:    t27 = (t26 - 0);
    t28 = (t27 * 1);
    t29 = (1U * t28);
    t7 = (t2 + t29);
    t30 = (0 - 15);
    t31 = (t30 * -1);
    t31 = (t31 + 1);
    t32 = (1U * t31);
    memset(t7, t4, t32);
    t8 = (t0 + 1032U);
    t9 = *((char **)t8);
    t10 = ((IEEE_P_2592010699) + 4000);
    t11 = (t14 + 0U);
    t13 = (t11 + 0U);
    *((int *)t13) = 0;
    t13 = (t11 + 4U);
    *((int *)t13) = 15;
    t13 = (t11 + 8U);
    *((int *)t13) = 1;
    t33 = (15 - 0);
    t34 = (t33 * 1);
    t34 = (t34 + 1);
    t13 = (t11 + 12U);
    *((unsigned int *)t13) = t34;
    t13 = (t0 + 5248U);
    t8 = xsi_base_array_concat(t8, t12, t10, (char)97, t1, t14, (char)97, t9, t13, (char)101);
    t34 = (16U + 16U);
    t19 = (32U != t34);
    if (t19 == 1)
        goto LAB26;

LAB27:    t15 = (t0 + 3328);
    t16 = (t15 + 56U);
    t20 = *((char **)t16);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t8, 32U);
    xsi_driver_first_trans_fast(t15);

LAB3:    t1 = (t0 + 3232);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(22, ng0);
    t8 = (t0 + 5372);
    t10 = (t0 + 1032U);
    t11 = *((char **)t10);
    t13 = ((IEEE_P_2592010699) + 4000);
    t15 = (t14 + 0U);
    t16 = (t15 + 0U);
    *((int *)t16) = 0;
    t16 = (t15 + 4U);
    *((int *)t16) = 15;
    t16 = (t15 + 8U);
    *((int *)t16) = 1;
    t17 = (15 - 0);
    t18 = (t17 * 1);
    t18 = (t18 + 1);
    t16 = (t15 + 12U);
    *((unsigned int *)t16) = t18;
    t16 = (t0 + 5248U);
    t10 = xsi_base_array_concat(t10, t12, t13, (char)97, t8, t14, (char)97, t11, t16, (char)101);
    t18 = (16U + 16U);
    t19 = (32U != t18);
    if (t19 == 1)
        goto LAB11;

LAB12:    t20 = (t0 + 3328);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t10, 32U);
    xsi_driver_first_trans_fast(t20);
    goto LAB3;

LAB5:    t5 = 0;

LAB8:    if (t5 < 2U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB6;

LAB10:    t5 = (t5 + 1);
    goto LAB8;

LAB11:    xsi_size_not_matching(32U, t18, 0);
    goto LAB12;

LAB13:    xsi_set_current_line(24, ng0);
    t8 = (t0 + 1032U);
    t9 = *((char **)t8);
    t8 = (t0 + 5390);
    t13 = ((IEEE_P_2592010699) + 4000);
    t15 = (t0 + 5248U);
    t16 = (t14 + 0U);
    t20 = (t16 + 0U);
    *((int *)t20) = 0;
    t20 = (t16 + 4U);
    *((int *)t20) = 15;
    t20 = (t16 + 8U);
    *((int *)t20) = 1;
    t17 = (15 - 0);
    t18 = (t17 * 1);
    t18 = (t18 + 1);
    t20 = (t16 + 12U);
    *((unsigned int *)t20) = t18;
    t11 = xsi_base_array_concat(t11, t12, t13, (char)97, t9, t15, (char)97, t8, t14, (char)101);
    t18 = (16U + 16U);
    t19 = (32U != t18);
    if (t19 == 1)
        goto LAB21;

LAB22:    t20 = (t0 + 3328);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t11, 32U);
    xsi_driver_first_trans_fast(t20);
    goto LAB3;

LAB15:    t5 = 0;

LAB18:    if (t5 < 2U)
        goto LAB19;
    else
        goto LAB17;

LAB19:    t6 = (t2 + t5);
    t7 = (t1 + t5);
    if (*((unsigned char *)t6) != *((unsigned char *)t7))
        goto LAB16;

LAB20:    t5 = (t5 + 1);
    goto LAB18;

LAB21:    xsi_size_not_matching(32U, t18, 0);
    goto LAB22;

LAB23:    t26 = 15;
    goto LAB25;

LAB26:    xsi_size_not_matching(32U, t34, 0);
    goto LAB27;

}

static void work_a_3056889143_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(31, ng0);

LAB3:    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t1 = (t0 + 3392);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 3248);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_3056889143_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3056889143_3212880686_p_0,(void *)work_a_3056889143_3212880686_p_1};
	xsi_register_didat("work_a_3056889143_3212880686", "isim/tb_IF_DEC_ALU_isim_beh.exe.sim/work/a_3056889143_3212880686.didat");
	xsi_register_executes(pe);
}
