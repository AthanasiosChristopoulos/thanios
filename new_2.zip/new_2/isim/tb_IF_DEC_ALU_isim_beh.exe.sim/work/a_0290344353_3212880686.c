/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ds123f15/Documents/Organization/Xilinx_Projects/new_2/MUX.vhd";
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_17802405650254020620_1035706684(char *, char *, char *);


static void work_a_0290344353_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    int t5;
    int t6;
    unsigned int t7;
    char *t8;
    char *t9;
    int t10;
    int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    int t19;
    char *t20;
    int t21;
    int t22;
    int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned char t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;

LAB0:    xsi_set_current_line(16, ng0);

LAB3:    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 1032U);
    t3 = *((char **)t1);
    t1 = (t0 + 4560U);
    t4 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t3, t1);
    t5 = (t4 * 32);
    t6 = (t5 + 31);
    t7 = (1023 - t6);
    t8 = (t0 + 1032U);
    t9 = *((char **)t8);
    t8 = (t0 + 4560U);
    t10 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t9, t8);
    t11 = (t10 * 32);
    xsi_vhdl_check_range_of_slice(1023, 0, -1, t6, t11, -1);
    t12 = (t7 * 1U);
    t13 = (0 + t12);
    t14 = (t2 + t13);
    t15 = (t0 + 1032U);
    t16 = *((char **)t15);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t16, t1);
    t18 = (t17 * 32);
    t19 = (t18 + 31);
    t15 = (t0 + 1032U);
    t20 = *((char **)t15);
    t21 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t20, t8);
    t22 = (t21 * 32);
    t23 = (t22 - t19);
    t24 = (t23 * -1);
    t24 = (t24 + 1);
    t25 = (1U * t24);
    t26 = (32U != t25);
    if (t26 == 1)
        goto LAB5;

LAB6:    t15 = (t0 + 2904);
    t27 = (t15 + 56U);
    t28 = *((char **)t27);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    memcpy(t30, t14, 32U);
    xsi_driver_first_trans_fast_port(t15);

LAB2:    t31 = (t0 + 2824);
    *((int *)t31) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(32U, t25, 0);
    goto LAB6;

}


extern void work_a_0290344353_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0290344353_3212880686_p_0};
	xsi_register_didat("work_a_0290344353_3212880686", "isim/tb_IF_DEC_ALU_isim_beh.exe.sim/work/a_0290344353_3212880686.didat");
	xsi_register_executes(pe);
}
