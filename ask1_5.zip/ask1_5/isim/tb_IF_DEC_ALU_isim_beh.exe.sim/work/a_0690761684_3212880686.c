/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ds123f15/Documents/Organization/Xilinx_Projects/ask1_5/ControlModule.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_2763492388968962707_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_0690761684_3212880686_p_0(char *t0)
{
    char t7[16];
    char t47[16];
    char t52[16];
    char t54[16];
    char t56[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    int t19;
    int t20;
    int t21;
    char *t22;
    int t23;
    char *t24;
    char *t25;
    int t26;
    char *t27;
    char *t28;
    int t29;
    char *t30;
    char *t31;
    int t32;
    char *t33;
    char *t34;
    int t35;
    char *t36;
    char *t37;
    int t38;
    char *t39;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    unsigned int t46;
    unsigned char t48;
    unsigned char t49;
    unsigned char t50;
    unsigned char t51;
    unsigned char t53;
    unsigned char t55;
    unsigned char t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;

LAB0:    xsi_set_current_line(29, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_2763492388968962707_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4584);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(34, ng0);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 8136U);
    t5 = (t0 + 8222);
    t8 = (t7 + 0U);
    t9 = (t8 + 0U);
    *((int *)t9) = 0;
    t9 = (t8 + 4U);
    *((int *)t9) = 5;
    t9 = (t8 + 8U);
    *((int *)t9) = 1;
    t10 = (5 - 0);
    t11 = (t10 * 1);
    t11 = (t11 + 1);
    t9 = (t8 + 12U);
    *((unsigned int *)t9) = t11;
    t12 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t4, t3, t5, t7);
    if (t12 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 4664);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(52, ng0);
    t1 = (t0 + 4728);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(53, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t11 = (5 - 5);
    t17 = (t11 * 1U);
    t18 = (0 + t17);
    t1 = (t3 + t18);
    t4 = (t7 + 0U);
    t5 = (t4 + 0U);
    *((int *)t5) = 5;
    t5 = (t4 + 4U);
    *((int *)t5) = 4;
    t5 = (t4 + 8U);
    *((int *)t5) = -1;
    t10 = (4 - 5);
    t46 = (t10 * -1);
    t46 = (t46 + 1);
    t5 = (t4 + 12U);
    *((unsigned int *)t5) = t46;
    t5 = (t0 + 8312);
    t8 = (t47 + 0U);
    t9 = (t8 + 0U);
    *((int *)t9) = 0;
    t9 = (t8 + 4U);
    *((int *)t9) = 1;
    t9 = (t8 + 8U);
    *((int *)t9) = 1;
    t19 = (1 - 0);
    t46 = (t19 * 1);
    t46 = (t46 + 1);
    t9 = (t8 + 12U);
    *((unsigned int *)t9) = t46;
    t2 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t1, t7, t5, t47);
    if (t2 != 0)
        goto LAB31;

LAB33:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t11 = (5 - 3);
    t17 = (t11 * 1U);
    t18 = (0 + t17);
    t1 = (t3 + t18);
    t4 = (t0 + 8318);
    t10 = xsi_mem_cmp(t4, t1, 4U);
    if (t10 == 1)
        goto LAB35;

LAB41:    t6 = (t0 + 8322);
    t19 = xsi_mem_cmp(t6, t1, 4U);
    if (t19 == 1)
        goto LAB36;

LAB42:    t9 = (t0 + 8326);
    t20 = xsi_mem_cmp(t9, t1, 4U);
    if (t20 == 1)
        goto LAB37;

LAB43:    t14 = (t0 + 8330);
    t21 = xsi_mem_cmp(t14, t1, 4U);
    if (t21 == 1)
        goto LAB38;

LAB44:    t16 = (t0 + 8334);
    t23 = xsi_mem_cmp(t16, t1, 4U);
    if (t23 == 1)
        goto LAB39;

LAB45:
LAB40:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 8358);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);

LAB34:
LAB32:
LAB6:    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 8136U);
    t4 = (t0 + 8362);
    t6 = (t7 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 0;
    t8 = (t6 + 4U);
    *((int *)t8) = 5;
    t8 = (t6 + 8U);
    *((int *)t8) = 1;
    t10 = (5 - 0);
    t11 = (t10 * 1);
    t11 = (t11 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t11;
    t50 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t3, t1, t4, t7);
    if (t50 == 1)
        goto LAB59;

LAB60:    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t8 = (t0 + 8136U);
    t13 = (t0 + 8368);
    t15 = (t47 + 0U);
    t16 = (t15 + 0U);
    *((int *)t16) = 0;
    t16 = (t15 + 4U);
    *((int *)t16) = 5;
    t16 = (t15 + 8U);
    *((int *)t16) = 1;
    t19 = (5 - 0);
    t11 = (t19 * 1);
    t11 = (t11 + 1);
    t16 = (t15 + 12U);
    *((unsigned int *)t16) = t11;
    t51 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t9, t8, t13, t47);
    t49 = t51;

LAB61:    if (t49 == 1)
        goto LAB56;

LAB57:    t16 = (t0 + 1192U);
    t22 = *((char **)t16);
    t16 = (t0 + 8136U);
    t24 = (t0 + 8374);
    t27 = (t52 + 0U);
    t28 = (t27 + 0U);
    *((int *)t28) = 0;
    t28 = (t27 + 4U);
    *((int *)t28) = 5;
    t28 = (t27 + 8U);
    *((int *)t28) = 1;
    t20 = (5 - 0);
    t11 = (t20 * 1);
    t11 = (t11 + 1);
    t28 = (t27 + 12U);
    *((unsigned int *)t28) = t11;
    t53 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t22, t16, t24, t52);
    t48 = t53;

LAB58:    if (t48 == 1)
        goto LAB53;

LAB54:    t28 = (t0 + 1192U);
    t30 = *((char **)t28);
    t28 = (t0 + 8136U);
    t31 = (t0 + 8380);
    t34 = (t54 + 0U);
    t36 = (t34 + 0U);
    *((int *)t36) = 0;
    t36 = (t34 + 4U);
    *((int *)t36) = 5;
    t36 = (t34 + 8U);
    *((int *)t36) = 1;
    t21 = (5 - 0);
    t11 = (t21 * 1);
    t11 = (t11 + 1);
    t36 = (t34 + 12U);
    *((unsigned int *)t36) = t11;
    t55 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t30, t28, t31, t54);
    t12 = t55;

LAB55:    if (t12 == 1)
        goto LAB50;

LAB51:    t36 = (t0 + 1192U);
    t37 = *((char **)t36);
    t36 = (t0 + 8136U);
    t39 = (t0 + 8386);
    t41 = (t56 + 0U);
    t42 = (t41 + 0U);
    *((int *)t42) = 0;
    t42 = (t41 + 4U);
    *((int *)t42) = 5;
    t42 = (t41 + 8U);
    *((int *)t42) = 1;
    t23 = (5 - 0);
    t11 = (t23 * 1);
    t11 = (t11 + 1);
    t42 = (t41 + 12U);
    *((unsigned int *)t42) = t11;
    t57 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t37, t36, t39, t56);
    t2 = t57;

LAB52:    if (t2 != 0)
        goto LAB47;

LAB49:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 4856);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);

LAB48:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 8136U);
    t4 = (t0 + 8392);
    t6 = (t7 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 0;
    t8 = (t6 + 4U);
    *((int *)t8) = 5;
    t8 = (t6 + 8U);
    *((int *)t8) = 1;
    t10 = (5 - 0);
    t11 = (t10 * 1);
    t11 = (t11 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t11;
    t48 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t3, t1, t4, t7);
    if (t48 == 1)
        goto LAB68;

LAB69:    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t8 = (t0 + 8136U);
    t13 = (t0 + 8398);
    t15 = (t47 + 0U);
    t16 = (t15 + 0U);
    *((int *)t16) = 0;
    t16 = (t15 + 4U);
    *((int *)t16) = 5;
    t16 = (t15 + 8U);
    *((int *)t16) = 1;
    t19 = (5 - 0);
    t11 = (t19 * 1);
    t11 = (t11 + 1);
    t16 = (t15 + 12U);
    *((unsigned int *)t16) = t11;
    t50 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t9, t8, t13, t47);
    if (t50 == 1)
        goto LAB71;

LAB72:    t49 = (unsigned char)0;

LAB73:    t12 = t49;

LAB70:    if (t12 == 1)
        goto LAB65;

LAB66:    t16 = (t0 + 1192U);
    t24 = *((char **)t16);
    t16 = (t0 + 8136U);
    t25 = (t0 + 8404);
    t28 = (t52 + 0U);
    t30 = (t28 + 0U);
    *((int *)t30) = 0;
    t30 = (t28 + 4U);
    *((int *)t30) = 5;
    t30 = (t28 + 8U);
    *((int *)t30) = 1;
    t20 = (5 - 0);
    t11 = (t20 * 1);
    t11 = (t11 + 1);
    t30 = (t28 + 12U);
    *((unsigned int *)t30) = t11;
    t57 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t24, t16, t25, t52);
    if (t57 == 1)
        goto LAB74;

LAB75:    t55 = (unsigned char)0;

LAB76:    t2 = t55;

LAB67:    if (t2 != 0)
        goto LAB62;

LAB64:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 4920);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB63:    xsi_set_current_line(88, ng0);
    t1 = (t0 + 4984);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(93, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 8136U);
    t4 = (t0 + 8410);
    t6 = (t7 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 0;
    t8 = (t6 + 4U);
    *((int *)t8) = 5;
    t8 = (t6 + 8U);
    *((int *)t8) = 1;
    t10 = (5 - 0);
    t11 = (t10 * 1);
    t11 = (t11 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t11;
    t12 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t3, t1, t4, t7);
    if (t12 == 1)
        goto LAB80;

LAB81:    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t8 = (t0 + 8136U);
    t13 = (t0 + 8416);
    t15 = (t47 + 0U);
    t16 = (t15 + 0U);
    *((int *)t16) = 0;
    t16 = (t15 + 4U);
    *((int *)t16) = 5;
    t16 = (t15 + 8U);
    *((int *)t16) = 1;
    t19 = (5 - 0);
    t11 = (t19 * 1);
    t11 = (t11 + 1);
    t16 = (t15 + 12U);
    *((unsigned int *)t16) = t11;
    t48 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t9, t8, t13, t47);
    t2 = t48;

LAB82:    if (t2 != 0)
        goto LAB77;

LAB79:    xsi_set_current_line(96, ng0);
    t1 = (t0 + 5048);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB78:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 8422);
    t10 = xsi_mem_cmp(t1, t3, 6U);
    if (t10 == 1)
        goto LAB84;

LAB87:    t5 = (t0 + 8428);
    t19 = xsi_mem_cmp(t5, t3, 6U);
    if (t19 == 1)
        goto LAB84;

LAB88:    t8 = (t0 + 8434);
    t20 = xsi_mem_cmp(t8, t3, 6U);
    if (t20 == 1)
        goto LAB85;

LAB89:
LAB86:    xsi_set_current_line(105, ng0);
    t1 = (t0 + 8444);
    t4 = (t0 + 5112);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast_port(t4);

LAB83:    xsi_set_current_line(111, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 8136U);
    t4 = (t0 + 8446);
    t6 = (t7 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 0;
    t8 = (t6 + 4U);
    *((int *)t8) = 5;
    t8 = (t6 + 8U);
    *((int *)t8) = 1;
    t10 = (5 - 0);
    t11 = (t10 * 1);
    t11 = (t11 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t11;
    t12 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t3, t1, t4, t7);
    if (t12 == 1)
        goto LAB94;

LAB95:    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t8 = (t0 + 8136U);
    t13 = (t0 + 8452);
    t15 = (t47 + 0U);
    t16 = (t15 + 0U);
    *((int *)t16) = 0;
    t16 = (t15 + 4U);
    *((int *)t16) = 5;
    t16 = (t15 + 8U);
    *((int *)t16) = 1;
    t19 = (5 - 0);
    t11 = (t19 * 1);
    t11 = (t11 + 1);
    t16 = (t15 + 12U);
    *((unsigned int *)t16) = t11;
    t48 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t9, t8, t13, t47);
    t2 = t48;

LAB96:    if (t2 != 0)
        goto LAB91;

LAB93:    xsi_set_current_line(114, ng0);
    t1 = (t0 + 5176);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB92:    xsi_set_current_line(120, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 8136U);
    t4 = (t0 + 8458);
    t6 = (t7 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 0;
    t8 = (t6 + 4U);
    *((int *)t8) = 5;
    t8 = (t6 + 8U);
    *((int *)t8) = 1;
    t10 = (5 - 0);
    t11 = (t10 * 1);
    t11 = (t11 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t11;
    t12 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t3, t1, t4, t7);
    if (t12 == 1)
        goto LAB100;

LAB101:    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t8 = (t0 + 8136U);
    t13 = (t0 + 8464);
    t15 = (t47 + 0U);
    t16 = (t15 + 0U);
    *((int *)t16) = 0;
    t16 = (t15 + 4U);
    *((int *)t16) = 5;
    t16 = (t15 + 8U);
    *((int *)t16) = 1;
    t19 = (5 - 0);
    t11 = (t19 * 1);
    t11 = (t11 + 1);
    t16 = (t15 + 12U);
    *((unsigned int *)t16) = t11;
    t48 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t9, t8, t13, t47);
    t2 = t48;

LAB102:    if (t2 != 0)
        goto LAB97;

LAB99:    xsi_set_current_line(123, ng0);
    t1 = (t0 + 5240);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB98:    goto LAB3;

LAB5:    xsi_set_current_line(35, ng0);
    t9 = (t0 + 4664);
    t13 = (t9 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);
    xsi_set_current_line(36, ng0);
    t1 = (t0 + 4728);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(37, ng0);
    t1 = (t0 + 1352U);
    t3 = *((char **)t1);
    t11 = (5 - 3);
    t17 = (t11 * 1U);
    t18 = (0 + t17);
    t1 = (t3 + t18);
    t4 = (t0 + 8228);
    t10 = xsi_mem_cmp(t4, t1, 4U);
    if (t10 == 1)
        goto LAB9;

LAB20:    t6 = (t0 + 8232);
    t19 = xsi_mem_cmp(t6, t1, 4U);
    if (t19 == 1)
        goto LAB10;

LAB21:    t9 = (t0 + 8236);
    t20 = xsi_mem_cmp(t9, t1, 4U);
    if (t20 == 1)
        goto LAB11;

LAB22:    t14 = (t0 + 8240);
    t21 = xsi_mem_cmp(t14, t1, 4U);
    if (t21 == 1)
        goto LAB12;

LAB23:    t16 = (t0 + 8244);
    t23 = xsi_mem_cmp(t16, t1, 4U);
    if (t23 == 1)
        goto LAB13;

LAB24:    t24 = (t0 + 8248);
    t26 = xsi_mem_cmp(t24, t1, 4U);
    if (t26 == 1)
        goto LAB14;

LAB25:    t27 = (t0 + 8252);
    t29 = xsi_mem_cmp(t27, t1, 4U);
    if (t29 == 1)
        goto LAB15;

LAB26:    t30 = (t0 + 8256);
    t32 = xsi_mem_cmp(t30, t1, 4U);
    if (t32 == 1)
        goto LAB16;

LAB27:    t33 = (t0 + 8260);
    t35 = xsi_mem_cmp(t33, t1, 4U);
    if (t35 == 1)
        goto LAB17;

LAB28:    t36 = (t0 + 8264);
    t38 = xsi_mem_cmp(t36, t1, 4U);
    if (t38 == 1)
        goto LAB18;

LAB29:
LAB19:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 8308);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);

LAB8:    goto LAB6;

LAB9:    xsi_set_current_line(38, ng0);
    t39 = (t0 + 8268);
    t41 = (t0 + 4792);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    memcpy(t45, t39, 4U);
    xsi_driver_first_trans_fast_port(t41);
    goto LAB8;

LAB10:    xsi_set_current_line(39, ng0);
    t1 = (t0 + 8272);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB11:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 8276);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB12:    xsi_set_current_line(41, ng0);
    t1 = (t0 + 8280);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB13:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 8284);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB14:    xsi_set_current_line(43, ng0);
    t1 = (t0 + 8288);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB15:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 8292);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB16:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 8296);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB17:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 8300);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB18:    xsi_set_current_line(47, ng0);
    t1 = (t0 + 8304);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB8;

LAB30:;
LAB31:    xsi_set_current_line(54, ng0);
    t9 = (t0 + 8314);
    t14 = (t0 + 4792);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t22 = (t16 + 56U);
    t24 = *((char **)t22);
    memcpy(t24, t9, 4U);
    xsi_driver_first_trans_fast_port(t14);
    goto LAB32;

LAB35:    xsi_set_current_line(57, ng0);
    t24 = (t0 + 8338);
    t27 = (t0 + 4792);
    t28 = (t27 + 56U);
    t30 = *((char **)t28);
    t31 = (t30 + 56U);
    t33 = *((char **)t31);
    memcpy(t33, t24, 4U);
    xsi_driver_first_trans_fast_port(t27);
    goto LAB34;

LAB36:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 8342);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB34;

LAB37:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 8346);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB34;

LAB38:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 8350);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB34;

LAB39:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 8354);
    t4 = (t0 + 4792);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB34;

LAB46:;
LAB47:    xsi_set_current_line(71, ng0);
    t42 = (t0 + 4856);
    t43 = (t42 + 56U);
    t44 = *((char **)t43);
    t45 = (t44 + 56U);
    t58 = *((char **)t45);
    *((unsigned char *)t58) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t42);
    goto LAB48;

LAB50:    t2 = (unsigned char)1;
    goto LAB52;

LAB53:    t12 = (unsigned char)1;
    goto LAB55;

LAB56:    t48 = (unsigned char)1;
    goto LAB58;

LAB59:    t49 = (unsigned char)1;
    goto LAB61;

LAB62:    xsi_set_current_line(80, ng0);
    t30 = (t0 + 4920);
    t33 = (t30 + 56U);
    t34 = *((char **)t33);
    t36 = (t34 + 56U);
    t37 = *((char **)t36);
    *((unsigned char *)t37) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t30);
    goto LAB63;

LAB65:    t2 = (unsigned char)1;
    goto LAB67;

LAB68:    t12 = (unsigned char)1;
    goto LAB70;

LAB71:    t16 = (t0 + 1512U);
    t22 = *((char **)t16);
    t51 = *((unsigned char *)t22);
    t53 = (t51 == (unsigned char)3);
    t49 = t53;
    goto LAB73;

LAB74:    t30 = (t0 + 1512U);
    t31 = *((char **)t30);
    t59 = *((unsigned char *)t31);
    t60 = (t59 == (unsigned char)2);
    t55 = t60;
    goto LAB76;

LAB77:    xsi_set_current_line(94, ng0);
    t16 = (t0 + 5048);
    t22 = (t16 + 56U);
    t24 = *((char **)t22);
    t25 = (t24 + 56U);
    t27 = *((char **)t25);
    *((unsigned char *)t27) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t16);
    goto LAB78;

LAB80:    t2 = (unsigned char)1;
    goto LAB82;

LAB84:    xsi_set_current_line(103, ng0);
    t13 = (t0 + 8440);
    t15 = (t0 + 5112);
    t16 = (t15 + 56U);
    t22 = *((char **)t16);
    t24 = (t22 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t13, 2U);
    xsi_driver_first_trans_fast_port(t15);
    goto LAB83;

LAB85:    xsi_set_current_line(104, ng0);
    t1 = (t0 + 8442);
    t4 = (t0 + 5112);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 2U);
    xsi_driver_first_trans_fast_port(t4);
    goto LAB83;

LAB90:;
LAB91:    xsi_set_current_line(112, ng0);
    t16 = (t0 + 5176);
    t22 = (t16 + 56U);
    t24 = *((char **)t22);
    t25 = (t24 + 56U);
    t27 = *((char **)t25);
    *((unsigned char *)t27) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t16);
    goto LAB92;

LAB94:    t2 = (unsigned char)1;
    goto LAB96;

LAB97:    xsi_set_current_line(121, ng0);
    t16 = (t0 + 5240);
    t22 = (t16 + 56U);
    t24 = *((char **)t22);
    t25 = (t24 + 56U);
    t27 = *((char **)t25);
    *((unsigned char *)t27) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t16);
    goto LAB98;

LAB100:    t2 = (unsigned char)1;
    goto LAB102;

}


extern void work_a_0690761684_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0690761684_3212880686_p_0};
	xsi_register_didat("work_a_0690761684_3212880686", "isim/tb_IF_DEC_ALU_isim_beh.exe.sim/work/a_0690761684_3212880686.didat");
	xsi_register_executes(pe);
}
