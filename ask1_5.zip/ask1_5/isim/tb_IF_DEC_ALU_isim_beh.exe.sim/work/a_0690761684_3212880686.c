/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ds123f15/Documents/Organization/Xilinx_Projects/ask1_5/ControlModule.vhd";
extern char *IEEE_P_3620187407;



static void work_a_0690761684_3212880686_p_0(char *t0)
{
    char t5[16];
    char t47[16];
    char t49[16];
    char t54[16];
    char t56[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    int t17;
    int t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    int t25;
    char *t26;
    char *t27;
    int t28;
    char *t29;
    char *t30;
    int t31;
    char *t32;
    char *t33;
    int t34;
    char *t35;
    char *t36;
    int t37;
    char *t38;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    unsigned char t45;
    unsigned char t46;
    unsigned char t48;
    unsigned char t50;
    unsigned int t51;
    unsigned char t52;
    unsigned char t53;
    unsigned char t55;
    unsigned char t57;
    char *t58;
    unsigned char t59;
    unsigned char t60;

LAB0:    xsi_set_current_line(35, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 8152U);
    t3 = (t0 + 8238);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 4664);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 8152U);
    t3 = (t0 + 8328);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t46 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t46 == 1)
        goto LAB34;

LAB35:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t7 = (t0 + 8152U);
    t12 = (t0 + 8334);
    t14 = (t47 + 0U);
    t20 = (t14 + 0U);
    *((int *)t20) = 0;
    t20 = (t14 + 4U);
    *((int *)t20) = 5;
    t20 = (t14 + 8U);
    *((int *)t20) = 1;
    t17 = (5 - 0);
    t9 = (t17 * 1);
    t9 = (t9 + 1);
    t20 = (t14 + 12U);
    *((unsigned int *)t20) = t9;
    t48 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t11, t7, t12, t47);
    t45 = t48;

LAB36:    if (t45 == 1)
        goto LAB31;

LAB32:    t20 = (t0 + 1192U);
    t21 = *((char **)t20);
    t20 = (t0 + 8152U);
    t23 = (t0 + 8340);
    t26 = (t49 + 0U);
    t27 = (t26 + 0U);
    *((int *)t27) = 0;
    t27 = (t26 + 4U);
    *((int *)t27) = 5;
    t27 = (t26 + 8U);
    *((int *)t27) = 1;
    t18 = (5 - 0);
    t9 = (t18 * 1);
    t9 = (t9 + 1);
    t27 = (t26 + 12U);
    *((unsigned int *)t27) = t9;
    t50 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t21, t20, t23, t49);
    t10 = t50;

LAB33:    if (t10 != 0)
        goto LAB28;

LAB30:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 4728);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);

LAB29:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t9 = (5 - 5);
    t15 = (t9 * 1U);
    t16 = (0 + t15);
    t1 = (t2 + t16);
    t3 = (t5 + 0U);
    t4 = (t3 + 0U);
    *((int *)t4) = 5;
    t4 = (t3 + 4U);
    *((int *)t4) = 4;
    t4 = (t3 + 8U);
    *((int *)t4) = -1;
    t8 = (4 - 5);
    t51 = (t8 * -1);
    t51 = (t51 + 1);
    t4 = (t3 + 12U);
    *((unsigned int *)t4) = t51;
    t4 = (t0 + 8346);
    t7 = (t47 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 0;
    t11 = (t7 + 4U);
    *((int *)t11) = 1;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t17 = (1 - 0);
    t51 = (t17 * 1);
    t51 = (t51 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t51;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t1, t5, t4, t47);
    if (t10 != 0)
        goto LAB37;

LAB39:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t9 = (5 - 5);
    t15 = (t9 * 1U);
    t16 = (0 + t15);
    t1 = (t2 + t16);
    t3 = (t0 + 8352);
    t8 = xsi_mem_cmp(t3, t1, 6U);
    if (t8 == 1)
        goto LAB41;

LAB49:    t6 = (t0 + 8358);
    t17 = xsi_mem_cmp(t6, t1, 6U);
    if (t17 == 1)
        goto LAB42;

LAB50:    t11 = (t0 + 8364);
    t18 = xsi_mem_cmp(t11, t1, 6U);
    if (t18 == 1)
        goto LAB43;

LAB51:    t13 = (t0 + 8370);
    t19 = xsi_mem_cmp(t13, t1, 6U);
    if (t19 == 1)
        goto LAB44;

LAB52:    t20 = (t0 + 8376);
    t22 = xsi_mem_cmp(t20, t1, 6U);
    if (t22 == 1)
        goto LAB45;

LAB53:    t23 = (t0 + 8382);
    t25 = xsi_mem_cmp(t23, t1, 6U);
    if (t25 == 1)
        goto LAB46;

LAB54:    t26 = (t0 + 8388);
    t28 = xsi_mem_cmp(t26, t1, 6U);
    if (t28 == 1)
        goto LAB47;

LAB55:
LAB48:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 8422);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);

LAB40:
LAB38:
LAB3:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 8152U);
    t3 = (t0 + 8426);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t50 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t50 == 1)
        goto LAB69;

LAB70:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t7 = (t0 + 8152U);
    t12 = (t0 + 8432);
    t14 = (t47 + 0U);
    t20 = (t14 + 0U);
    *((int *)t20) = 0;
    t20 = (t14 + 4U);
    *((int *)t20) = 5;
    t20 = (t14 + 8U);
    *((int *)t20) = 1;
    t17 = (5 - 0);
    t9 = (t17 * 1);
    t9 = (t9 + 1);
    t20 = (t14 + 12U);
    *((unsigned int *)t20) = t9;
    t52 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t11, t7, t12, t47);
    t48 = t52;

LAB71:    if (t48 == 1)
        goto LAB66;

LAB67:    t20 = (t0 + 1192U);
    t21 = *((char **)t20);
    t20 = (t0 + 8152U);
    t23 = (t0 + 8438);
    t26 = (t49 + 0U);
    t27 = (t26 + 0U);
    *((int *)t27) = 0;
    t27 = (t26 + 4U);
    *((int *)t27) = 5;
    t27 = (t26 + 8U);
    *((int *)t27) = 1;
    t18 = (5 - 0);
    t9 = (t18 * 1);
    t9 = (t9 + 1);
    t27 = (t26 + 12U);
    *((unsigned int *)t27) = t9;
    t53 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t21, t20, t23, t49);
    t46 = t53;

LAB68:    if (t46 == 1)
        goto LAB63;

LAB64:    t27 = (t0 + 1192U);
    t29 = *((char **)t27);
    t27 = (t0 + 8152U);
    t30 = (t0 + 8444);
    t33 = (t54 + 0U);
    t35 = (t33 + 0U);
    *((int *)t35) = 0;
    t35 = (t33 + 4U);
    *((int *)t35) = 5;
    t35 = (t33 + 8U);
    *((int *)t35) = 1;
    t19 = (5 - 0);
    t9 = (t19 * 1);
    t9 = (t9 + 1);
    t35 = (t33 + 12U);
    *((unsigned int *)t35) = t9;
    t55 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t29, t27, t30, t54);
    t45 = t55;

LAB65:    if (t45 == 1)
        goto LAB60;

LAB61:    t35 = (t0 + 1192U);
    t36 = *((char **)t35);
    t35 = (t0 + 8152U);
    t38 = (t0 + 8450);
    t40 = (t56 + 0U);
    t41 = (t40 + 0U);
    *((int *)t41) = 0;
    t41 = (t40 + 4U);
    *((int *)t41) = 5;
    t41 = (t40 + 8U);
    *((int *)t41) = 1;
    t22 = (5 - 0);
    t9 = (t22 * 1);
    t9 = (t9 + 1);
    t41 = (t40 + 12U);
    *((unsigned int *)t41) = t9;
    t57 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t36, t35, t38, t56);
    t10 = t57;

LAB62:    if (t10 != 0)
        goto LAB57;

LAB59:    xsi_set_current_line(85, ng0);
    t1 = (t0 + 4856);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);

LAB58:    xsi_set_current_line(91, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 8152U);
    t3 = (t0 + 8456);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t46 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t46 == 1)
        goto LAB78;

LAB79:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t7 = (t0 + 8152U);
    t12 = (t0 + 8462);
    t14 = (t47 + 0U);
    t20 = (t14 + 0U);
    *((int *)t20) = 0;
    t20 = (t14 + 4U);
    *((int *)t20) = 5;
    t20 = (t14 + 8U);
    *((int *)t20) = 1;
    t17 = (5 - 0);
    t9 = (t17 * 1);
    t9 = (t9 + 1);
    t20 = (t14 + 12U);
    *((unsigned int *)t20) = t9;
    t50 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t11, t7, t12, t47);
    if (t50 == 1)
        goto LAB81;

LAB82:    t48 = (unsigned char)0;

LAB83:    t45 = t48;

LAB80:    if (t45 == 1)
        goto LAB75;

LAB76:    t20 = (t0 + 1192U);
    t23 = *((char **)t20);
    t20 = (t0 + 8152U);
    t24 = (t0 + 8468);
    t27 = (t49 + 0U);
    t29 = (t27 + 0U);
    *((int *)t29) = 0;
    t29 = (t27 + 4U);
    *((int *)t29) = 5;
    t29 = (t27 + 8U);
    *((int *)t29) = 1;
    t18 = (5 - 0);
    t9 = (t18 * 1);
    t9 = (t9 + 1);
    t29 = (t27 + 12U);
    *((unsigned int *)t29) = t9;
    t57 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t23, t20, t24, t49);
    if (t57 == 1)
        goto LAB84;

LAB85:    t55 = (unsigned char)0;

LAB86:    t10 = t55;

LAB77:    if (t10 != 0)
        goto LAB72;

LAB74:    xsi_set_current_line(94, ng0);
    t1 = (t0 + 4920);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB73:    xsi_set_current_line(100, ng0);
    t1 = (t0 + 4984);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(105, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 8152U);
    t3 = (t0 + 8474);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t45 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t45 == 1)
        goto LAB90;

LAB91:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t7 = (t0 + 8152U);
    t12 = (t0 + 8480);
    t14 = (t47 + 0U);
    t20 = (t14 + 0U);
    *((int *)t20) = 0;
    t20 = (t14 + 4U);
    *((int *)t20) = 5;
    t20 = (t14 + 8U);
    *((int *)t20) = 1;
    t17 = (5 - 0);
    t9 = (t17 * 1);
    t9 = (t9 + 1);
    t20 = (t14 + 12U);
    *((unsigned int *)t20) = t9;
    t46 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t11, t7, t12, t47);
    t10 = t46;

LAB92:    if (t10 != 0)
        goto LAB87;

LAB89:    xsi_set_current_line(108, ng0);
    t1 = (t0 + 5048);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB88:    xsi_set_current_line(114, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 8486);
    t8 = xsi_mem_cmp(t1, t2, 6U);
    if (t8 == 1)
        goto LAB94;

LAB97:    t4 = (t0 + 8492);
    t17 = xsi_mem_cmp(t4, t2, 6U);
    if (t17 == 1)
        goto LAB94;

LAB98:    t7 = (t0 + 8498);
    t18 = xsi_mem_cmp(t7, t2, 6U);
    if (t18 == 1)
        goto LAB95;

LAB99:
LAB96:    xsi_set_current_line(117, ng0);
    t1 = (t0 + 8508);
    t3 = (t0 + 5112);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 2U);
    xsi_driver_first_trans_fast_port(t3);

LAB93:    xsi_set_current_line(123, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 8152U);
    t3 = (t0 + 8510);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t45 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t45 == 1)
        goto LAB104;

LAB105:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t7 = (t0 + 8152U);
    t12 = (t0 + 8516);
    t14 = (t47 + 0U);
    t20 = (t14 + 0U);
    *((int *)t20) = 0;
    t20 = (t14 + 4U);
    *((int *)t20) = 5;
    t20 = (t14 + 8U);
    *((int *)t20) = 1;
    t17 = (5 - 0);
    t9 = (t17 * 1);
    t9 = (t9 + 1);
    t20 = (t14 + 12U);
    *((unsigned int *)t20) = t9;
    t46 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t11, t7, t12, t47);
    t10 = t46;

LAB106:    if (t10 != 0)
        goto LAB101;

LAB103:    xsi_set_current_line(126, ng0);
    t1 = (t0 + 5176);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB102:    xsi_set_current_line(132, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 8152U);
    t3 = (t0 + 8522);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 5;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t45 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t45 == 1)
        goto LAB110;

LAB111:    t7 = (t0 + 1192U);
    t11 = *((char **)t7);
    t7 = (t0 + 8152U);
    t12 = (t0 + 8528);
    t14 = (t47 + 0U);
    t20 = (t14 + 0U);
    *((int *)t20) = 0;
    t20 = (t14 + 4U);
    *((int *)t20) = 5;
    t20 = (t14 + 8U);
    *((int *)t20) = 1;
    t17 = (5 - 0);
    t9 = (t17 * 1);
    t9 = (t9 + 1);
    t20 = (t14 + 12U);
    *((unsigned int *)t20) = t9;
    t46 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t11, t7, t12, t47);
    t10 = t46;

LAB112:    if (t10 != 0)
        goto LAB107;

LAB109:    xsi_set_current_line(135, ng0);
    t1 = (t0 + 5240);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB108:    t1 = (t0 + 4584);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(36, ng0);
    t7 = (t0 + 4664);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(37, ng0);
    t1 = (t0 + 4728);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(38, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t9 = (5 - 3);
    t15 = (t9 * 1U);
    t16 = (0 + t15);
    t1 = (t2 + t16);
    t3 = (t0 + 8244);
    t8 = xsi_mem_cmp(t3, t1, 4U);
    if (t8 == 1)
        goto LAB6;

LAB17:    t6 = (t0 + 8248);
    t17 = xsi_mem_cmp(t6, t1, 4U);
    if (t17 == 1)
        goto LAB7;

LAB18:    t11 = (t0 + 8252);
    t18 = xsi_mem_cmp(t11, t1, 4U);
    if (t18 == 1)
        goto LAB8;

LAB19:    t13 = (t0 + 8256);
    t19 = xsi_mem_cmp(t13, t1, 4U);
    if (t19 == 1)
        goto LAB9;

LAB20:    t20 = (t0 + 8260);
    t22 = xsi_mem_cmp(t20, t1, 4U);
    if (t22 == 1)
        goto LAB10;

LAB21:    t23 = (t0 + 8264);
    t25 = xsi_mem_cmp(t23, t1, 4U);
    if (t25 == 1)
        goto LAB11;

LAB22:    t26 = (t0 + 8268);
    t28 = xsi_mem_cmp(t26, t1, 4U);
    if (t28 == 1)
        goto LAB12;

LAB23:    t29 = (t0 + 8272);
    t31 = xsi_mem_cmp(t29, t1, 4U);
    if (t31 == 1)
        goto LAB13;

LAB24:    t32 = (t0 + 8276);
    t34 = xsi_mem_cmp(t32, t1, 4U);
    if (t34 == 1)
        goto LAB14;

LAB25:    t35 = (t0 + 8280);
    t37 = xsi_mem_cmp(t35, t1, 4U);
    if (t37 == 1)
        goto LAB15;

LAB26:
LAB16:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 8324);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);

LAB5:    goto LAB3;

LAB6:    xsi_set_current_line(39, ng0);
    t38 = (t0 + 8284);
    t40 = (t0 + 4792);
    t41 = (t40 + 56U);
    t42 = *((char **)t41);
    t43 = (t42 + 56U);
    t44 = *((char **)t43);
    memcpy(t44, t38, 4U);
    xsi_driver_first_trans_fast_port(t40);
    goto LAB5;

LAB7:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 8288);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB5;

LAB8:    xsi_set_current_line(41, ng0);
    t1 = (t0 + 8292);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB5;

LAB9:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 8296);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB5;

LAB10:    xsi_set_current_line(43, ng0);
    t1 = (t0 + 8300);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB5;

LAB11:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 8304);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB5;

LAB12:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 8308);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB5;

LAB13:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 8312);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB5;

LAB14:    xsi_set_current_line(47, ng0);
    t1 = (t0 + 8316);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB5;

LAB15:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 8320);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB5;

LAB27:;
LAB28:    xsi_set_current_line(55, ng0);
    t27 = (t0 + 4728);
    t29 = (t27 + 56U);
    t30 = *((char **)t29);
    t32 = (t30 + 56U);
    t33 = *((char **)t32);
    *((unsigned char *)t33) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t27);
    goto LAB29;

LAB31:    t10 = (unsigned char)1;
    goto LAB33;

LAB34:    t45 = (unsigned char)1;
    goto LAB36;

LAB37:    xsi_set_current_line(62, ng0);
    t11 = (t0 + 8348);
    t13 = (t0 + 4792);
    t14 = (t13 + 56U);
    t20 = *((char **)t14);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    memcpy(t23, t11, 4U);
    xsi_driver_first_trans_fast_port(t13);
    goto LAB38;

LAB41:    xsi_set_current_line(66, ng0);
    t29 = (t0 + 8394);
    t32 = (t0 + 4792);
    t33 = (t32 + 56U);
    t35 = *((char **)t33);
    t36 = (t35 + 56U);
    t38 = *((char **)t36);
    memcpy(t38, t29, 4U);
    xsi_driver_first_trans_fast_port(t32);
    goto LAB40;

LAB42:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 8398);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB40;

LAB43:    xsi_set_current_line(68, ng0);
    t1 = (t0 + 8402);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB40;

LAB44:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 8406);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB40;

LAB45:    xsi_set_current_line(70, ng0);
    t1 = (t0 + 8410);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB40;

LAB46:    xsi_set_current_line(71, ng0);
    t1 = (t0 + 8414);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB40;

LAB47:    xsi_set_current_line(72, ng0);
    t1 = (t0 + 8418);
    t3 = (t0 + 4792);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB40;

LAB56:;
LAB57:    xsi_set_current_line(83, ng0);
    t41 = (t0 + 4856);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    t44 = (t43 + 56U);
    t58 = *((char **)t44);
    *((unsigned char *)t58) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t41);
    goto LAB58;

LAB60:    t10 = (unsigned char)1;
    goto LAB62;

LAB63:    t45 = (unsigned char)1;
    goto LAB65;

LAB66:    t46 = (unsigned char)1;
    goto LAB68;

LAB69:    t48 = (unsigned char)1;
    goto LAB71;

LAB72:    xsi_set_current_line(92, ng0);
    t29 = (t0 + 4920);
    t32 = (t29 + 56U);
    t33 = *((char **)t32);
    t35 = (t33 + 56U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t29);
    goto LAB73;

LAB75:    t10 = (unsigned char)1;
    goto LAB77;

LAB78:    t45 = (unsigned char)1;
    goto LAB80;

LAB81:    t20 = (t0 + 1512U);
    t21 = *((char **)t20);
    t52 = *((unsigned char *)t21);
    t53 = (t52 == (unsigned char)3);
    t48 = t53;
    goto LAB83;

LAB84:    t29 = (t0 + 1512U);
    t30 = *((char **)t29);
    t59 = *((unsigned char *)t30);
    t60 = (t59 == (unsigned char)2);
    t55 = t60;
    goto LAB86;

LAB87:    xsi_set_current_line(106, ng0);
    t20 = (t0 + 5048);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    t24 = (t23 + 56U);
    t26 = *((char **)t24);
    *((unsigned char *)t26) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t20);
    goto LAB88;

LAB90:    t10 = (unsigned char)1;
    goto LAB92;

LAB94:    xsi_set_current_line(115, ng0);
    t12 = (t0 + 8504);
    t14 = (t0 + 5112);
    t20 = (t14 + 56U);
    t21 = *((char **)t20);
    t23 = (t21 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t12, 2U);
    xsi_driver_first_trans_fast_port(t14);
    goto LAB93;

LAB95:    xsi_set_current_line(116, ng0);
    t1 = (t0 + 8506);
    t3 = (t0 + 5112);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    memcpy(t11, t1, 2U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB93;

LAB100:;
LAB101:    xsi_set_current_line(124, ng0);
    t20 = (t0 + 5176);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    t24 = (t23 + 56U);
    t26 = *((char **)t24);
    *((unsigned char *)t26) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t20);
    goto LAB102;

LAB104:    t10 = (unsigned char)1;
    goto LAB106;

LAB107:    xsi_set_current_line(133, ng0);
    t20 = (t0 + 5240);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    t24 = (t23 + 56U);
    t26 = *((char **)t24);
    *((unsigned char *)t26) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t20);
    goto LAB108;

LAB110:    t10 = (unsigned char)1;
    goto LAB112;

}


extern void work_a_0690761684_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0690761684_3212880686_p_0};
	xsi_register_didat("work_a_0690761684_3212880686", "isim/tb_IF_DEC_ALU_isim_beh.exe.sim/work/a_0690761684_3212880686.didat");
	xsi_register_executes(pe);
}
